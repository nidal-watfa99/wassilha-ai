/* App layout: sidebar (desktop) + mobile tabs, header, and the call overlay. */
import React, { useEffect, useRef, useState } from "react";
import { Link, NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useApp } from "../context/AppContext";
import { useRealtime } from "../context/RealtimeContext";
import { useCall } from "../context/CallContext";
import {
  IconHome, IconUsers, IconChat, IconPhone, IconVideo, IconSpark, IconSquare,
  IconCalendar, IconDoc, IconChart, IconBox, IconCalc, IconGear, IconMenu,
  IconLogout, IconSearch, IconMic, IconStop,
} from "./Icons";
import { LOCALES } from "../i18n";
import { LOCAL_MODE } from "../services/api";

const NAV = [
  { to: "/", key: "dashboard", Icon: IconHome, end: true },
  { to: "/contacts", key: "contacts", Icon: IconUsers },
  { to: "/messages", key: "messages", Icon: IconChat },
  { to: "/ai", key: "ai", Icon: IconSpark },
  { to: "/tasks", key: "tasks", Icon: IconSquare },
  { to: "/calendar", key: "calendar", Icon: IconCalendar },
  { to: "/documents", key: "documents", Icon: IconDoc },
  { to: "/insights", key: "insights", Icon: IconChart },
  { to: "/products", key: "products", Icon: IconBox },
  { to: "/calculator", key: "calculator", Icon: IconCalc },
  { to: "/settings", key: "settings", Icon: IconGear },
];

const MOBILE_NAV = [
  { to: "/", key: "dashboard", Icon: IconHome, end: true },
  { to: "/messages", key: "messages", Icon: IconChat },
  { to: "/contacts", key: "contacts", Icon: IconUsers },
  { to: "/tasks", key: "tasks", Icon: IconSquare },
  { to: "/ai", key: "ai", Icon: IconSpark },
  { to: "/settings", key: "settings", Icon: IconGear },
];

export function Layout() {
  const { t, user, logout } = useApp();
  const rt = useRealtime();
  const { call } = useCall();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  // close the mobile sidebar on navigation
  useEffect(() => setSidebarOpen(false), [location.pathname]);

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${sidebarOpen ? "open" : ""}`}>
        <div className="sidebar-brand">
          <div className="brand-orb" aria-hidden="true">و</div>
          <div>
            <div className="brand-name silver-blue-text">{t("appName")}</div>
            <div style={{ fontSize: "0.7rem", color: "var(--text-3)" }}>{t("tagline")}</div>
          </div>
        </div>
        <nav className="sidebar-nav" aria-label={t("appName")}>
          {NAV.map(({ to, key, Icon, end }) => (
            <NavLink key={to} to={to} end={end}
                     className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}>
              <Icon />
              <span>{t(key)}</span>
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-foot">
          <div style={{ display: "flex", alignItems: "center", gap: "0.6rem", padding: "0.25rem 0.5rem" }}>
            <div className="avatar" style={{ width: 36, height: 36, fontSize: "0.8rem" }}>
              {(user?.name || "?").slice(0, 1).toUpperCase()}
            </div>
            <div style={{ minWidth: 0, flex: 1 }}>
              <div style={{ fontSize: "var(--text-sm)", fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {user?.name}
              </div>
              <div style={{ fontSize: "0.68rem", color: "var(--text-3)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {user?.email}
              </div>
            </div>
            <button className="icon-btn" style={{ width: 38, height: 38 }} onClick={handleLogout}
                    aria-label={t("logout")} title={t("logout")}>
              <IconLogout />
            </button>
          </div>
        </div>
      </aside>

      <div className="main-area">
        <header className="main-header">
          <button className="icon-btn menu-toggle" onClick={() => setSidebarOpen((v) => !v)} aria-label="menu">
            <IconMenu />
          </button>
          <h1 className="silver-text">{t(location.state?.pageTitle || currentTitle(location.pathname, t))}</h1>
          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <span className={`badge ${rt.online ? "badge-green" : ""}`} title={t("sessionActive")}>
              {rt.online ? "●" : "○"}
            </span>
            <LangSwitch compact />
          </div>
        </header>
        <main className="page">
          {LOCAL_MODE && (
            <div className="glass" role="note"
                 style={{ padding: "0.55rem 0.9rem", marginBottom: "0.9rem", fontSize: "var(--text-xs)", color: "var(--text-2)" }}>
              {t("localModeBanner")}
            </div>
          )}
          <Outlet />
        </main>
        <nav className="mobile-tabs" aria-label="primary">
          {MOBILE_NAV.map(({ to, key, Icon, end }) => (
            <NavLink key={to} to={to} end={end} className={({ isActive }) => (isActive ? "active" : "")}>
              <Icon />
              <span>{t(key)}</span>
            </NavLink>
          ))}
        </nav>
      </div>

      {call.status !== "idle" && <CallOverlay />}
    </div>
  );
}

function currentTitle(pathname, t) {
  const found = NAV.find((n) => (n.end ? pathname === n.to : pathname.startsWith(n.to)));
  return found ? found.key : "dashboard";
}

export function LangSwitch({ compact }) {
  const { locale, setLocale } = useApp();
  return (
    <div className="lang-switch" role="group" aria-label="language">
      {Object.entries(LOCALES).map(([code, { label }]) => (
        <button key={code} onClick={() => setLocale(code)} aria-pressed={locale === code}>
          {code.toUpperCase()}
        </button>
      ))}
    </div>
  );
}

/* Full-screen call UI: local + remote video, status, and device controls. */
function CallOverlay() {
  const { t } = useApp();
  const { call, remoteStream, micOn, camOn, endCall, acceptCall, declineCall, toggleMic, toggleCam, localStreamRef } = useCall();
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);

  // attach the local stream preview
  useEffect(() => {
    if (localVideoRef.current && localStreamRef.current) {
      localVideoRef.current.srcObject = localStreamRef.current;
      localVideoRef.current.play().catch(() => {});
    }
  }, [call.status, localStreamRef]);

  // attach the remote stream when it arrives
  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
      remoteVideoRef.current.play().catch(() => {});
    }
  }, [remoteStream]);

  const statusText = {
    ringing: `${t("incomingCall")} — ${call.peerName || ""}`,
    calling: `${t("calling")} ${call.peerName || ""}…`,
    connecting: t("calling"),
    connected: t("connected"),
    ended: call.text || t("ended"),
  }[call.status] || "";

  return (
    <div className="call-overlay">
      <video ref={remoteVideoRef} className="call-video" autoPlay playsInline />
      <video ref={localVideoRef} className="call-video" style={{ width: "min(40vw, 240px)", position: "absolute", insetInlineEnd: "1rem", top: "1rem", border: "1px solid var(--border-strong)" }} autoPlay muted playsInline />
      <div className="call-status">{statusText}</div>
      <div className="call-controls">
        {call.status === "ringing" ? (
          <>
            <button className="btn btn-primary" onClick={acceptCall}><IconPhone />{t("accept")}</button>
            <button className="btn btn-danger" onClick={declineCall}><IconX />{t("decline")}</button>
          </>
        ) : (
          <>
            <button className="btn btn-ghost" onClick={toggleMic}>
              {micOn ? <IconMic /> : <IconMic style={{ opacity: 0.4 }} />}
              {micOn ? t("mute") : t("unmute")}
            </button>
            <button className="btn btn-ghost" onClick={toggleCam}>
              <IconVideo style={{ opacity: camOn ? 1 : 0.4 }} />
              {camOn ? t("cameraOff") : t("cameraOn")}
            </button>
            <button className="btn btn-danger" onClick={endCall}>
              <IconPhone style={{ transform: "rotate(135deg)" }} />
              {t("endCall")}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
